<?php
session_start();
include_once('db/config.php');

if (isset ($_SESSION['loginstatus'])and $_SESSION['loginstatus']==TRUE){
header('location:Home.php');
}else{
	


?>
<!DOCTYPE html>
<html lang="en">
<head>
	<title>Test Phase</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
<!--===============================================================================================-->	
	<link rel="icon" type="image/png" href="images/icons/favicon.ico"/>
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
<!--===============================================================================================-->
<link rel="stylesheet" type="text/css" href="fonts/font-awesome-4.7.0/css/font-awesome.min.css">
	
	<link rel="stylesheet" type="text/css" href="css/main.css">
<!--===============================================================================================-->
</head>
<body>
	
		<div class="container-login100">
			<div class="wrap-login100">
					<span class="login10-form-title">
						Online Property Rental and verification System
					</span>
		<div class="container-linkedlogin100-form-btn">
						<a class="text1" href="Register.php">
					    Register
							
						</a>
					</div>
					
		<div class="container-linkedlogin100-form-btn">
						<a class="text" href="login.php">
					     Login
							
						</a>
					</div>
		</div>
	</div>


	<script src="js/jquery-3.2.1.min.js"></script>

	<script src="js/bootstrap.min.js"></script>


</body>
</html>
<?php
}
?>