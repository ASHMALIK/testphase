<?php
session_start();
if(isset($_SESSION['loginstatus'])){
unset($_SESSION['loginstatus']);
session_destroy();
header('location:login.php');
}else {
	header('location:login.php');
}

?>
