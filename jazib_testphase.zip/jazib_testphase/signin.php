<?php
include_once('db/config.php');

$name=$_REQUEST['name'];
$pass=$_REQUEST['pass'];

$sql="select * from tbl_users where USER_NAME='$name' and PASSWORD='$pass' ";
$res=$conn->query($sql);
$rec=$res->fetch_array();
if(mysqli_num_rows($res)==1){
session_start();
$_SESSION['loginstatus']=TRUE;

 $_SESSION['id'] =$rec['VU_ID'];
 $_SESSION['name'] = $rec['USER_NAME'];
 $_SESSION['image'] = $rec['IMAGE'];


 header('location:Home.php?login=succesfully');
}
else{
header('location:login.php?error=error');
}

?>
