-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server version:               10.1.33-MariaDB - mariadb.org binary distribution
-- Server OS:                    Win32
-- HeidiSQL Version:             9.3.0.4984
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

-- Dumping database structure for jazib_testphase
DROP DATABASE IF EXISTS `jazib_testphase`;
CREATE DATABASE IF NOT EXISTS `jazib_testphase` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `jazib_testphase`;


-- Dumping structure for table jazib_testphase.tbl_users
DROP TABLE IF EXISTS `tbl_users`;
CREATE TABLE IF NOT EXISTS `tbl_users` (
  `VU_ID` varchar(250) NOT NULL,
  `USER_NAME` varchar(250) NOT NULL,
  `PASSWORD` varchar(250) NOT NULL,
  `IMAGE` varchar(250) NOT NULL,
  `USER_TYPE` varchar(50) NOT NULL,
  `TIME_STAMP` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table jazib_testphase.tbl_users: ~10 rows (approximately)
/*!40000 ALTER TABLE `tbl_users` DISABLE KEYS */;
REPLACE INTO `tbl_users` (`VU_ID`, `USER_NAME`, `PASSWORD`, `IMAGE`, `USER_TYPE`, `TIME_STAMP`) VALUES
	('bc140402941', 'jazib', 'password', '39989088_2148116498773494_2868039333313511424_n.jpg', 'Property Owner', '2019-02-05 14:53:34');
/*!40000 ALTER TABLE `tbl_users` ENABLE KEYS */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
