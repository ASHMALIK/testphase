<?php
include_once('db/config.php');

if(isset($_POST['submit'])){

$id = $_POST['id'];
$name=$_POST['name'];
$pass=$_POST['pass'];

$image = $_FILES['image']['name'];
$image_tmp = $_FILES['image']['tmp_name'];
move_uploaded_file($image_tmp, "images/Users/$image");

$usertype = $_POST['usertype'];

$sql="insert into tbl_users (VU_ID,USER_NAME,PASSWORD,IMAGE,USER_TYPE )values('$id','$name' ,'$pass','$image','$usertype')";

$res=$conn->query($sql);

	$sql = "select * from tbl_users where USER_NAME='$name' and PASSWORD='$pass' ";
	$res = $conn->query($sql);
	$rec = $res->fetch_array();
	if (mysqli_num_rows($res) == 1) {
	session_start();
	$_SESSION['loginstatus'] = true;
    $_SESSION['id'] = $rec['VU_ID'];
	$_SESSION['name'] = $rec['USER_NAME'];
	$_SESSION['image'] = $rec['IMAGE'];


		header('location:Home.php?login=succesfully');
	}
else{
	header('location:Register.php?error=error');
}
}
?>