<?php
session_start();
include_once('db/config.php');

if (isset($_SESSION['loginstatus']) and $_SESSION['loginstatus'] == true) {
  $ID=$_SESSION['id'];
  $Name=$_SESSION['name'];
  $Image= $_SESSION['image'] ;

?>
<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">

<title>Test Phase</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
<!--===============================================================================================-->	
	<link rel="icon" type="image/png" href="images/icons/favicon.ico"/>
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="fonts/font-awesome-4.7.0/css/font-awesome.min.css">

	<link rel="stylesheet" type="text/css" href="css/main.css">
<!--===============================================================================================-->
</head>
<body>

<div style="background-color:#ffffff;padding:15px;text-align:right;">
   <a href="logout.php"><button class="btn btn-dark">Logout</button></a>
</div>

<div id="main" class="container-login100">
  <div class="container-fluid">
 <div class="row">
    <div class="col-xs-7 col-sm-6 col-lg-8"><h1>VU_ID:- <?= $ID ?></h1></div>
    <div class="col-xs-5 col-sm-6 col-lg-4"><h1>NAME:- <?= $Name ?></h1></div>
  </div>
  <p><img class="img" src="images/Users/<?=$Image ?>"></p>
 
</div>
    
</div>

     
</body>
</html> 
<?php

} else {
  header('location:logout.php');
}
?>
